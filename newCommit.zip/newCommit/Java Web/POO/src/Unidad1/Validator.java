package Unidad1;

/** 
 * Permite limpiar y validar distintos tipos de parámetros para la gestión de usuarios
 * @author swd
 * @version 0.1.0 
 **/

public class Validator {

	/**
	  * Procesa un nombre de ususario y devuelve una cadena válida.
	  * @param userName El nombre de usuario
	  * @return El nombre de usuario limpio de caracteres inválidos
	  */
	public String cleanUserName(String userName) {
		
		userName = userName.trim().replaceAll("\\W+", "");
		return userName;
	}
	
	
	/** 
	 * Procesa una eda de usuario y devuelve la cadena validar.
	 * @param age Edad del usuario
	 * @return Un valor numérico (entero) con la edad del usuario.
	 */
	public int cleanAge(String age) {
		
		age = age.trim().replaceAll("\\D+", "");
		return Integer.parseInt(age);
	}
	
}

/**
 * Verifica que un parámetro sea un valor entero entre max y min.
 * @param numericValue valor numérico como una cadena que debe cumplir con la condición min y max
 * @param min valor minimo con el que se validará el numericValue
 * @param max valor maximo con el que se validará el numericValue
 * @return El valor numérico como entero entre un min y un max. Devuelve cero si el numericValue no cumple con el rango min y max
 * @version 0.1.0
 */

 public int maxInt(String numericValue, int min, int max){
     numericValue = numericValue.trim();

     if( numericValue.matches("\\d+") ){

        int number = Integer.parseInt(numericValue);

        if( number >= min && number<= max ){
            return number;
        }

     }
     return 0;
 }