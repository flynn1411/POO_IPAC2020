package Unidad1;

/** 
 * Hereda las caracteristicas de un humano
 * @author swd
 * @version 0.1.0
 */

public class Student extends Human{

	/** N�mero de cuenta*/
	private String account;
	
	/** Carrera a la que pertenece*/
	private int faculty;
	
}
