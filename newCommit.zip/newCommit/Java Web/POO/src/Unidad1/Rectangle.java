package Unidad1;

/** 
 * Permite dibujar una figura rectangular en la pantalla usando etiquetas de HTML.
 * @author POO
 * @version 0.1.0
 */

public class Rectangle{
    /** 
     * Constructor vacío de clase
     */

     public Rectangle(){}

     public String draw(Point p, int h, int w){

        StringBuilder result = new StringBuilder("");
        return result.toString();
     }

     public String draw(Point pointA, Point pointB){

        StringBuilder result = new StringBuilder("");
        return result.toString();
     }

}